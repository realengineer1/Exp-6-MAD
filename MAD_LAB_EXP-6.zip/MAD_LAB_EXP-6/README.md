# Experiment 6: Routes and Consume API
To develop multiple activities and navigate through routes for our Flutter application. During this experiment, we acquired knowledge about:
Navigate between activities using routes
Pass data through routing
Consume API
